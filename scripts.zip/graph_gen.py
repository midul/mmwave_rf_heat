from csv import reader
from numpy import genfromtxt
import matplotlib.pyplot as plt


per_data=genfromtxt('data_peak.csv',delimiter=',')
print(per_data)
plt.plot(per_data)
plt.show()
plt.savefig('data_peak.png')

per_data=genfromtxt('data_range.csv',delimiter=',')
print(per_data)
plt.plot(per_data)
plt.show()
plt.savefig('data_range.png')
