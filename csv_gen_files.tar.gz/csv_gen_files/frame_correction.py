import sys

linelist = []

# with open('temp_no_space.txt') as f:
#   lineList = f.readlines()

linelist = [line.rstrip('\n') for line in open(sys.argv[1])]

i = 1;
obj_detected = -1
frame_number = 0
length = len(linelist)
f= open("generated_new_csv_frame_corrected.csv","w")
line_csv="S.No,Frame_NO.,Target_Total,Target_NO.,X(m),Y(m),Z(m),Velocity(m/s),Peakval(Not_Log)\n"
f.write(line_csv)
print("the lenght is: ", length)
while i < length:
    # print(linelist[i])
    obj_detected_new = (linelist[i].split(",")[1])
    if obj_detected != obj_detected_new:
        obj_detected = obj_detected_new
        frame_number = frame_number + 1
    line_to_add = str(linelist[i].split(",")[0]) + "," + \
                  str(frame_number) + "," + \
                  str(linelist[i].split(",")[2]) + "," + \
                  str(linelist[i].split(",")[3]) + "," + \
                  str(linelist[i].split(",")[4]) + "," + \
                  str(linelist[i].split(",")[5]) + "," + \
                  str(linelist[i].split(",")[6]) + "," + \
                  "0" + "," + \
                  str(linelist[i].split(",")[7]) + "\n"
    f.write(line_to_add)
 #   print("writting" + str(frame_number))
    i = i + 1

#print("Out of loop")
f.close()
