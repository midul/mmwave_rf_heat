import sys

linelist = []

# with open('temp_no_space.txt') as f:
#   lineList = f.readlines()

linelist = [line.rstrip('\n') for line in open(sys.argv[1])]

count = 0

# for line in linelist:
    # print(line)
    # ++count
    # if count == 10:
    #     break


# print(linelist)

f= open("generated_new_csv.csv","w")

count = 1
line_csv="S.No,Frame_NO.,Target_Total,Target_NO.,X(m),Y(m),Z(m),Peakval(Not_Log)\n"
f.write(line_csv)
line_csv = ""

line_csv = str(count)
line_len = len(linelist)
i = 0
packetID = ""
DetectObj = ""
ObjId = ""
PeakVal = ""
X = ""
Y = ""
Z = ""
while i < line_len:
    if "PacketID:" in linelist[i]:
        packetID = str(linelist[i].split(":")[1])
        line_csv = str(line_csv) + "," + packetID
        i = i + 5
    if "DetectObj:" in linelist[i]:
        DetectObj = str(linelist[i].split(":")[1])
        line_csv = str(line_csv) + "," + DetectObj
    if "ObjId:" in linelist[i]:
        ObjId = str(int(linelist[i].split(":")[1]) + 1)
        line_csv = str(line_csv) + "," + ObjId
    if "PeakVal:" in linelist[i]:
        PeakVal = str(linelist[i].split(":")[1])
        line_csv = str(line_csv) + "," + PeakVal
    if "X:" in linelist[i]:
        X = str(linelist[i].split(":")[1])
        line_csv = str(line_csv) + "," + X
    if "Y:" in linelist[i]:
        Y = str(linelist[i].split(":")[1])
        line_csv = str(line_csv) + "," + Y
    if "Z:" in linelist[i]:
        Z = str(linelist[i].split(":")[1])
        line_csv = str(count) + "," + packetID+ "," + DetectObj+ "," + ObjId + "," + X + "," + Y + "," + Z + "," + PeakVal + "\n"
        # line_csv = str(line_csv) + "," + Z
        count = count + 1
        # line_csv = line_csv + "\n"
        f.write(line_csv)
        line_csv = str(count)
    i = i + 1

f.close()

