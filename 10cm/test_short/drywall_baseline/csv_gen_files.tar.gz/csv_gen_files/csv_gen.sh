#!/bin/sh

EXT=dat
for i in *; do
	if [ "${i}" != "${i%.${EXT}}" ];then
		python2 ./parseTLV.py $i >> temp.txt
	fi
done

tr -d ' \t\r\f' < temp.txt > temp_no_space.txt

python csv_gen.py temp_no_space.txt

